package controller.recruit;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.Company;
import model.Recruit;
import model.service.CompanyManager;
import model.service.RecruitManager;

public class ViewRecruitController implements Controller {
    
	@Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {			
    	
    	int i;
    	Recruit recruit = null;
    	
		RecruitManager rcMan = RecruitManager.getInstance();
		String comName = request.getParameter("comName");
		
		List<Recruit> rcList = rcMan.findRecruitList();
		for (i=0; i<rcList.size(); i++) {
			if (rcList.get(i).getName().equals(comName))
				recruit = rcList.get(i);
		}
		
		request.setAttribute("recruit", recruit);	// ä�� ���� ����				
		return "/recruit/view.jsp";			// ä�� ���� ���� ȭ������ �̵�
    }
}