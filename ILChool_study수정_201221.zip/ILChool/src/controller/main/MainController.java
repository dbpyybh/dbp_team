package controller.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.TO_DO_LIST;
import model.service.TodoManager;


public class MainController implements Controller {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	/* 1. �޷� ������ �޾ƿ��� �κ� */
    	
    	
    	
    	
    	
    	/* 2. ���θ���Ʈ �޾ƿ��� �κ� */
    	HttpSession session = request.getSession();
        String memberid = MemberSessionUtils.getLoginmemberId(session);
        
        TodoManager manager = TodoManager.getInstance();
		List<TO_DO_LIST> todolist = manager.getTodoList(memberid);
		
        request.setAttribute("todolist", todolist);
        manager.getTodoList(memberid);
    	
    	return "/main/MainUI.jsp";
    }
}
