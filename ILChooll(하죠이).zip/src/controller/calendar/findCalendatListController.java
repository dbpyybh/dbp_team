package controller.calendar;

import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import model.FullCalendar;
import model.service.*;
import controller.Controller;
import controller.member.MemberSessionUtils;

public class findCalendatListController implements Controller {

	 private static final Logger log = LoggerFactory.getLogger(findCalendatListController.class);
	 
	 public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		 SimpleDateFormat df = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
		 HttpSession session = request.getSession();
	     String memberid = MemberSessionUtils.getLoginmemberId(session);
	     
	     FullCalendar cal = new FullCalendar(request.getParameter("company_name")
	    		 			, df.parse(request.getParameter("end_date")));
	     
	     try {
	    	 FullCalendarManager calMan = FullCalendarManager.getInstance();
	    	 calMan.findCalendarList(memberid, cal);
	     }
	    		
	 }
}
