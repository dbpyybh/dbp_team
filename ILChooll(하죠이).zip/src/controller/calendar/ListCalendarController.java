package controller.calendar;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.member.MemberSessionUtils;
import model.FullCalendar;
import model.service.FullCalendarManager;

public class ListCalendarController {
public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		SimpleDateFormat df = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
		HttpSession session = request.getSession();
		String memberid = MemberSessionUtils.getLoginmemberId(session);
    	FullCalendarManager recMan = FullCalendarManager.getInstance();
    	
		List<FullCalendar> recList = recMan.FindCalendarList(memberid, request.getParameter("company_name"), df.parse(request.getParameter("end_date")));
		
		// recrList�� request�� �����Ͽ� ä����� �˻� ȭ������ ����(forwarding)
		request.setAttribute("recList", recList);
		return "/recruit/searchRecruit.jsp";  
    }
}
