package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ToodoDAO {
	
	public ToodoDAO() { 
		  try {
		   Class.forName("oracle.jdbc.driver.OracleDriver"); 
		  } catch (ClassNotFoundException ex) {
		   ex.printStackTrace();
		  } 
	}

	 private static Connection getConnection() {
		  String url = // "jdbc:oracle:thin:@localhost:1521:xe";
		     "jdbc:oracle:thin:@202.20.119.117:1521:orcl"; 
		  String user = "dbprog0210";
		  String passwd = "TIGER";
		
		  // DBMS와 연결 획득
		  Connection conn = null;
		  try {
		   conn = DriverManager.getConnection(url, user, passwd);
		  } catch (SQLException e) {
		   e.printStackTrace();
		  } 
		  return conn;
	 }
	public int getListCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;   // PreparedStatment 참조변수 생성
		ResultSet rs = null;
		int cnt = 0;
		try {
			conn = getOracle();
			String sql = "select count(*) from TO_DO_LIST";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				cnt = rs.getInt("count(*)");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {rs.close();}catch(SQLException s) {}
			try {pstmt.close();}catch(SQLException s) {}
			try {conn.close();}catch(SQLException s) {}
		}
		return cnt;
	}
	
	public List getList(int start, int end) {
		Connection conn = null;
		PreparedStatement pstmt = null;   // PreparedStatment 참조변수 생성
		ResultSet rs = null;
		
		List list = null;
		try {
			conn = getOracle();
			String sql1 = "select TO_DO * from TO_DO_LIST";
			pstmt = conn.prepareStatement(sql1);
			rs = pstmt.executeQuery();
			list = new ArrayList(end);
			while(rs.next()) {
				TodoDTO dto = 
			}
		}
	}
}
