package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import model.FullCalendar;
import controller.member.MemberSessionUtils;

public class CalendarDAO {
	 private JDBCUtil jdbcUtil = null;
	   
	   public CalendarDAO() {         
	      jdbcUtil = new JDBCUtil();   //  JDBCUtil 媛앹껜 �깮�꽦
	   }
	   
	   public List<FullCalendar> FindCalendarList(String memberid, String company_name, Date end_date) throws SQLException {
		   java.sql.Date endDate = new java.sql.Date(cal.getEndDate().getYear(), cal.getEndDate().getMonth(), cal.getEndDate().getDay());
			String sql = "SELECT COMPANY_NAME, DEADLINE " + "FROM RECRUIT_WISH " + "WHERE MEMBERID = ?";
		
			Object[] param = new Object[] {memberid};
			jdbcUtil.setSqlAndParameters(sql, param);
			
			try {
				ResultSet rs = jdbcUtil.executeQuery();
				List<FullCalendar> allcalList = new ArrayList<FullCalendar>();
				while(rs.next()) {
					FullCalendar com = new FullCalendar(rs.getString("company_name"), rs.getDate("end_date"));
					
				}
				return allcalList;
			}catch (Exception ex) {
				ex.printStackTrace();
			}finally {
				jdbcUtil.close();
			}
			return null;
		}
}
