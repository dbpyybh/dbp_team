package model.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import model.FullCalendar;
import model.dao.CalendarDAO;

public class FullCalendarManager {
	private static FullCalendarManager calMan = new FullCalendarManager();
	private CalendarDAO calDAO;
	
	private FullCalendarManager() {
		try {
			calDAO = new CalendarDAO();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static FullCalendarManager getInstance() {
		return calMan;
	}
	
	public List<FullCalendar> findCalendarList(String memberid, String company_name, Date end_date) throws SQLException {
		return calDAO.FindCalendarList(memberid, company_name, end_date);
	}
}
