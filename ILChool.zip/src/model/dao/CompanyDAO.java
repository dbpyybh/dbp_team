package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import model.Company;
import model.Recruit;

public class CompanyDAO {
	private JDBCUtil jdbcUtil = null;

	public CompanyDAO() {
		jdbcUtil = new JDBCUtil();
	};
	
	public List<Company> findCompanyListFromWorknet(String comName) {
		try {
			CompanyXmlParser parser = new CompanyXmlParser();
			List<Company> comList;	// Community���� ����Ʈ ����
			comList = parser.parse(comName);
			
			return comList;
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public Company create(Company com) throws SQLException {
		String sql = "INSERT INTO COMPANY VALUES (companyid_seq.nextval, ?, ?, ?, ?)";		
		Object[] param = new Object[] {com.getName(), com.getForm(),
			com.getSummary(), com.getUrl()};

		jdbcUtil.setSqlAndParameters(sql, param);	// JDBCUtil �� insert���� �Ű� ���� ����
						
		String key[] = {"company_id"};	// PK �÷��� �̸�     
		try {    
			jdbcUtil.executeUpdate(key);  // insert �� ����
		   	ResultSet rs = jdbcUtil.getGeneratedKeys();
		   	if(rs.next()) {
		   		int generatedKey = rs.getInt(1);   // ������ PK ��
		   		com.setCompany_id(generatedKey); 	// id�ʵ忡 ����  
		   	}
		   	return com;
		} catch (Exception ex) {
			jdbcUtil.rollback();
			ex.printStackTrace();
		} finally {		
			jdbcUtil.commit();
			jdbcUtil.close();	// resource ��ȯ
		}		
		return null;			
	}
}