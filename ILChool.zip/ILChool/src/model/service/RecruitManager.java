package model.service;

import java.util.List;

import model.Recruit;
import model.dao.CompanyDAO;
import model.dao.RecruitDAO;

public class RecruitManager {
	private static RecruitManager recruitMan = new RecruitManager();
	private RecruitDAO recDAO;
	private CompanyDAO comDAO;

	private RecruitManager() {
		try {
			recDAO = new RecruitDAO();
			comDAO = new CompanyDAO();
		} catch (Exception e) {
			e.printStackTrace();
		}			
	}
	
	public static RecruitManager getInstance() {
		return recruitMan;
	}
	
	public List<Recruit> findRecruitList() {
		return recDAO.findRecruitListFromWorknet();
	}
}
