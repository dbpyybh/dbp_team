package model;

import java.util.Date;

public class Recruit {
	private int Recruit_id;
	private String Name;
	private String Url;
	private String Form;
	private String Title;
	private String Location;
	private String Job;
	private String WorkingType;
	private Date RegDate;
	private Date Deadline;
	private int Company_id;
	
	public Recruit() { }

	public Recruit(int recruit_id, String name, String url, String form, String title, String location, String job,
			String workingType, Date regDate, Date deadline, int company_id) {
		super();
		Recruit_id = recruit_id;
		Name = name;
		Url = url;
		Form = form;
		Title = title;
		Location = location;
		Job = job;
		WorkingType = workingType;
		RegDate = regDate;
		Deadline = deadline;
		Company_id = company_id;
	}

	public int getRecruit_id() {
		return Recruit_id;
	}

	public void setRecruit_id(int recruit_id) {
		Recruit_id = recruit_id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getUrl() {
		return Url;
	}

	public void setUrl(String url) {
		Url = url;
	}

	public String getForm() {
		return Form;
	}

	public void setForm(String form) {
		Form = form;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getJob() {
		return Job;
	}

	public void setJob(String job) {
		Job = job;
	}

	public String getWorkingType() {
		return WorkingType;
	}

	public void setWorkingType(String workingType) {
		WorkingType = workingType;
	}
	

	public Date getRegDate() {
		return RegDate;
	}

	public void setRegDate(Date regDate) {
		RegDate = regDate;
	}

	public Date getDeadline() {
		return Deadline;
	}

	public void setDeadline(Date deadline) {
		Deadline = deadline;
	}

	public int getCompany_id() {
		return Company_id;
	}

	public void setCompany_id(int company_id) {
		Company_id = company_id;
	}
	
}
