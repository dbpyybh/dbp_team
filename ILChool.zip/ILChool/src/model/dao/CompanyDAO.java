package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import model.Company;
import model.Recruit;

public class CompanyDAO {
	public CompanyDAO() {};
	
	public List<Company> findCompanyListFromWorknet(String comName) {
		try {
			CompanyXmlParser parser = new CompanyXmlParser();
			List<Company> comList;	// Community���� ����Ʈ ����
			comList = parser.parse(comName);
			
			return comList;
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}	
}