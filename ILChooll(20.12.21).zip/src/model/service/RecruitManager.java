package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Recruit;
import model.dao.CompanyDAO;
import model.dao.RecruitDAO;

public class RecruitManager {
	private static RecruitManager recruitMan = new RecruitManager();
	private RecruitDAO recDAO;

	private RecruitManager() {
		try {
			recDAO = new RecruitDAO();
		} catch (Exception e) {
			e.printStackTrace();
		}			
	}
	
	public static RecruitManager getInstance() {
		return recruitMan;
	}
	
	public List<Recruit> findRecruitList() {
		return recDAO.findRecruitListFromWorknet();
	}
	
	public Recruit createRecruit(Recruit rec) throws SQLException {
		return recDAO.create(rec);
	}
}
