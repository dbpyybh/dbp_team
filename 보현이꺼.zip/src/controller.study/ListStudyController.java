package controller.study;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

import model.Study;
import controller.Controller;
import model.service.StudyManager;

public class ListStudyController implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		StudyManager manager = StudyManager.getInstance();
		List<Study> studyList = manager.getStudyList();
		
		//studyList ��ü�� request�� �����Ͽ� Ŀ�´�Ƽ ����Ʈ ȭ������ �̵�(forwarding)
		request.setAttribute("studyList", studyList);
		return "/study/studyList.jsp";
	}



}
