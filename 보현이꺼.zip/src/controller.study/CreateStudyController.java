package controller.study;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Study;
import model.service.StudyManager;

public class CreateStudyController implements Controller {
	private static final Logger log = LoggerFactory.getLogger(CreateStudyController.class);

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Study study = new Study(
				0, request.getParameter("title"), request.getParameter("writer"), request.getParameter("reportingDate"),
				request.getParameter("category"), request.getParameter("location"), request.getParameter("age"),
				request.getParameter("companyname"), Integer.parseInt(request.getParameter("headcount")), Integer.parseInt(request.getParameter("period")), 0);
		
		try {
			StudyManager manager = StudyManager.getInstance();
			manager.create(study);
		
			log.debug("Create Study : {}", study);
			return "redirect:/study/list";
		} catch (Exception e) {
			request.setAttribute("creationFailed", true);
			request.setAttribute("exception", e);
			request.setAttribute("study", study);
			return "/study/studyCreation.jsp";
		}
		
		
	}
}
