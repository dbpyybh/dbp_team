package controller.todo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.TO_DO_LIST;
import model.service.TodoManager;

public class TodoController implements Controller{
	private static final Logger log = LoggerFactory.getLogger(TodoController.class);
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)throws Exception{
		TO_DO_LIST todolist = new TO_DO_LIST(request.getParameter("TO_DO"));
		try {
			TodoManager manager = TodoManager.getInstance();
			manager.create(todolist);
			
			log.debug("Create TODO: {}", todolist);
			return "redirect:/DBPTeam/MainUI";
		}catch (Exception e) {
			request.setAttribute("Failed", true);
			request.setAttribute("exception", e);
			return "/ILChooll/WebContent/DBPTeam/ToDo.jsp";
		}
	}
}
