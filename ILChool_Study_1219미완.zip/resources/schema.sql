DROP SEQUENCE Sequence_269;

CREATE SEQUENCE Sequence_269
	INCREMENT BY 1
	START WITH 1;

DROP TABLE FamousSaying CASCADE CONSTRAINTS PURGE;

DROP TABLE TO_DO_LIST CASCADE CONSTRAINTS PURGE;

DROP TABLE Study_add_list CASCADE CONSTRAINTS PURGE;

DROP TABLE Study CASCADE CONSTRAINTS PURGE;

DROP TABLE Company_wish CASCADE CONSTRAINTS PURGE;

DROP TABLE Recruit_wish CASCADE CONSTRAINTS PURGE;

DROP TABLE Recruit CASCADE CONSTRAINTS PURGE;

DROP TABLE Company CASCADE CONSTRAINTS PURGE;

DROP TABLE Member CASCADE CONSTRAINTS PURGE;

CREATE TABLE Company
(
	company_id           INT NOT NULL ,
	name                 VARCHAR2(50) NULL ,
	form                 VARCHAR2(10) NULL ,
	summary              VARCHAR2(50) NULL ,
	location             VARCHAR2(10) NULL ,
	industry             VARCHAR2(10) NULL ,
	salary               INT NULL ,
	ceo                  VARCHAR2(40) NULL 
);

ALTER TABLE Company
	ADD CONSTRAINT  XPKCompany PRIMARY KEY (company_id);

CREATE TABLE Member
(
	memberId             VARCHAR2(40) NOT NULL ,
	password             VARCHAR2(20) NULL ,
	name                 VARCHAR2(40) NULL ,
	email                VARCHAR2(40) NULL ,
	phone                VARCHAR2(15) NULL ,
	age                  INT NULL 

);

ALTER TABLE Member
	ADD CONSTRAINT  XPKMember PRIMARY KEY (memberId);

CREATE TABLE TO_DO_LIST
(
	memberId            INT NOT NULL ,
	TO_DO                VARCHAR2(50) NULL ,
	TO_DO_id             INT NOT NULL 
);

ALTER TABLE TO_DO_LIST
	ADD CONSTRAINT  XPKTO_DO_LIST PRIMARY KEY (TO_DO_id,memberId);

CREATE TABLE Company_wish
(
	memberId            INT NOT NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Company_wish
	ADD CONSTRAINT  XPKCompany_wish PRIMARY KEY (memberId,company_id);

CREATE TABLE FamousSaying
(
	FamousSaying_id      INT NOT NULL ,
	FamousSaying         VARCHAR2(100) NULL 
);

ALTER TABLE FamousSaying
	ADD CONSTRAINT  XPKFamousSaying PRIMARY KEY (FamousSaying_id);

CREATE TABLE Recruit
(
	recruit_id           INT NOT NULL ,
	name                 VARCHAR2(40) NULL ,
	url                  VARCHAR2(2100) NULL ,
	form                 VARCHAR2(10) NULL ,
	career               VARCHAR2(10) NULL ,
	title                VARCHAR2(50) NULL ,
	location             VARCHAR2(10) NULL ,
	industry             VARCHAR2(10) NULL ,
	job                  VARCHAR2(18) NULL ,
	workingType          VARCHAR2(10) NULL ,
	regDate              DATE NULL ,
	deadline             DATE NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Recruit
	ADD CONSTRAINT  XPKRecruit PRIMARY KEY (recruit_id,company_id);

CREATE TABLE Recruit_wish
(
	memberId            INT NOT NULL ,
	recruit_id           INT NOT NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Recruit_wish
	ADD CONSTRAINT  XPKRecruit_wish PRIMARY KEY (memberId,recruit_id,company_id);

CREATE TABLE Study
(
	Study_id             INT NOT NULL ,
	title                VARCHAR2(50) NULL ,
	category             VARCHAR2(20) NULL ,
	location             VARCHAR2(10) NULL ,
	age                  VARCHAR2(10) NULL ,
	companyName          VARCHAR2(50) NULL ,
	headcount            INT NULL ,
	period               INT NULL ,
	company_id           INT NOT NULL 
);

INSERT INTO Member VALUES ('admin', 'admin', 'admin', 'admin@dongduk.ac.kr', '010-9140-9999', '21');
