package model.dao;

import java.util.List;
import java.util.ArrayList;
import java.sql.*;
import model.Study;

public class StudyDAO {
	private JDBCUtil jdbcUtil = null;
	
	public StudyDAO() {
		jdbcUtil = new JDBCUtil();
	}
	
	//���͵� ���̺��� ���ο� �� ���� !
	public int create(Study study) throws SQLException {
		String sql = "INSERT INTO STUDY VALUES (STUDYID_SEQ.nextval, ?, ?, SYSDATE, ?, ?, ?, ?, ?, ?, 1)";
		Object[] param = new Object[] {study.getTitle(),
				study.getWriter(), study.getCategory(), 
				study.getLocation(), study.getAge(), study.getCompanyName(), study.getPeriod(), 
				study.getMaxHeadcount()};
		jdbcUtil.setSqlAndParameters(sql, param);
		
		try {
			int result = jdbcUtil.executeUpdate();
			return result;
		} catch (Exception ex) {
			jdbcUtil.rollback();
			ex.printStackTrace();
		} finally {
			jdbcUtil.commit();
			jdbcUtil.close();
		}
		return 0;
	}
	
	//������ ���͵� ������ ����
	public int updateStudy(Study study) throws SQLException {
		String sql = "UPDATE STUDY " //reportingDate -> �����Ϸ� �ٲ�����
				+ "SET title=?, reportingDate=?, category=?, location=?, age=?, companyName=?, period=?, maxHeadcount=? "
				+ "WHERE study_id=?";
		Object[] param = new Object[] {study.getTitle(), study.getReportingDate(), study.getCategory(), 
				study.getLocation(), study.getAge(), study.getCompanyName(), study.getPeriod(), 
				study.getMaxHeadcount(), study.getStudy_id()};
		jdbcUtil.setSqlAndParameters(sql, param);
		
		try {
			int result = jdbcUtil.executeUpdate();
			return result;
		} catch (Exception ex) {
			jdbcUtil.rollback();
			ex.printStackTrace();
		} finally {
			jdbcUtil.commit();
			jdbcUtil.close();
		}
		return 0;
	}
	
	//study_id�� �ش��ϴ� ���͵� ����
	public int deleteStudy(int study_id) throws SQLException {
		String sql = "DELETE FROM STUDY WHERE study_id=?";
		jdbcUtil.setSqlAndParameters(sql, new Object[] {study_id});
		
		try {
			int result = jdbcUtil.executeUpdate();
			return result;
		} catch (Exception ex) {
			jdbcUtil.rollback();
			ex.printStackTrace();
		} finally {
			jdbcUtil.commit();
			jdbcUtil.close();
		}
		return 0;
	}
	
	//study_id�� �ش��ϴ� ���͵� ������ ã�� ������ Ŭ������ ������ �����Ͽ� ��ȯ
	public Study getStudyByNo(int study_id) throws SQLException {
		String sql = "SELECT title, writer, reportingDate, category, location, age, companyName, period, maxHeadcount, currHeadcount "
				+ "FROM STUDY " + "WHERE study_id=? ";
		jdbcUtil.setSqlAndParameters(sql, new Object[] {study_id});
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			if (rs.next()) {
				Study study = new Study(
						study_id,
						rs.getString("title"), rs.getString("writer"),
						rs.getDate("reportingDate"), rs.getString("category"),
						rs.getString("location"), rs.getString("age"),
						rs.getString("companyName"), rs.getInt("period"),
						rs.getInt("maxHeadcount"), rs.getInt("currHeadcount"));
						return study;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	
	//��� ���͵� ����Ʈ ��ȯ
	public List<Study> getAllStudyList() throws SQLException {
		String sql = "SELECT study_id, title, writer, reportingDate, category, location, age, companyName, period, maxHeadcount, currHeadcount "
				+ "FROM STUDY";
		jdbcUtil.setSqlAndParameters(sql, null);
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			List<Study> allStudyList = new ArrayList<Study>();
			while (rs.next()) {
				Study study = new Study(
						rs.getInt("study_id"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getDate("reportingDate"),
						rs.getString("category"),
						rs.getString("location"),
						rs.getString("age"),
						rs.getString("companyName"),
						rs.getInt("period"),
						rs.getInt("maxHeadcount"),
						rs.getInt("currHeadcount"));
				allStudyList.add(study);
			}
			return allStudyList;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	
	/* ��ü ����� ���� �˻��� �� ���� �������� �������� ����� ����� ���� �̿��Ͽ� �ش��ϴ� ����� �������� List�� �����Ͽ� ��ȯ */
	public List<Study> getAllStudyList(int currentPage, int countPerPage) throws SQLException {
		String sql = "SELECT study_id, title, writer, reportingDate, category, location, age, companyName, period, maxHeadcount, currHeadcount "
				+ "FROM STUDY";
		jdbcUtil.setSqlAndParameters(sql, null,
				ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			List<Study> allStudyList = new ArrayList<Study>();
			while (rs.next()) {
				Study study = new Study(
						rs.getInt("study_id"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getDate("reportingDate"),
						rs.getString("category"),
						rs.getString("location"),
						rs.getString("age"),
						rs.getString("companyName"),
						rs.getInt("period"),
						rs.getInt("maxHeadcount"),
						rs.getInt("currHeadcount"));
				allStudyList.add(study);
			}
			return allStudyList;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	
	//����� ���͵� ����Ʈ ��ȯ
	public List<Study> getStudyByCompany(String companyName) throws SQLException {
		String sql = "SELECT study_id, title, writer, reportingDate, category, location, age, compaName, period, maxHeadcount, currHeadcount "
				+ "FROM STUDY " + "WHERE companyName = ?";
		jdbcUtil.setSqlAndParameters(sql,  new Object[] {companyName});
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			List<Study> studyListByCom = new ArrayList<Study>();
			while (rs.next()) {
				Study study = new Study(
						rs.getInt("study_id"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getDate("reportingDate"),
						rs.getString("category"),
						rs.getString("location"),
						rs.getString("age"),
						rs.getString("companyName"),
						rs.getInt("period"),
						rs.getInt("maxHeadcount"),
						rs.getInt("currHeadcount"));
				studyListByCom.add(study);
			}
			return studyListByCom;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	
	//������ ���͵� ����Ʈ ��ȯ
	public List<Study> getStudyByCategory(String category) {
		String sql = "SELECT study_id, title, writer, reportingDate, category, location, age, companyName, period, maxHeadcount, currHeadcount "
				+ "FROM STUDY " + "WHERE category = ?";
		jdbcUtil.setSqlAndParameters(sql,  new Object[] {category});
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			List<Study> studyListByCat = new ArrayList<Study>();
			while (rs.next()) {
				Study study = new Study(
						rs.getInt("study_id"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getDate("reportingDate"),
						rs.getString("category"),
						rs.getString("location"),
						rs.getString("age"),
						rs.getString("companyName"),
						rs.getInt("period"),
						rs.getInt("maxHeadcount"),
						rs.getInt("currHeadcount"));
				studyListByCat.add(study);
			}
			return studyListByCat;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	
	//������ ���͵� ����Ʈ ��ȯ
	public List<Study> getStudyByLocation(String location) {
		String sql = "SELECT study_id, title, writer, reportingDate, category, location, age, companyName, period, maxHeadcount, currHeadcount "
				+ "FROM STUDY " + "WHERE location = ?";
		jdbcUtil.setSqlAndParameters(sql,  new Object[] {location});
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			List<Study> studyListByLoc = new ArrayList<Study>();
			while (rs.next()) {
				Study study = new Study(
						rs.getInt("study_id"),
						rs.getString("title"),
						rs.getString("writer"),
						rs.getDate("reportingDate"),
						rs.getString("category"),
						rs.getString("location"),
						rs.getString("age"),
						rs.getString("companyName"),
						rs.getInt("period"),
						rs.getInt("maxHeadcount"),
						rs.getInt("currHeadcount"));
				studyListByLoc.add(study);
			}
			return studyListByLoc;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	
	
}
