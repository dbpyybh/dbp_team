package controller.study;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.service.StudyManager;
import model.Member;
import model.Study;
import model.service.MemberManager;

public class RegisterStudyController implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		StudyManager sManager = StudyManager.getInstance();
		MemberManager mManager = MemberManager.getInstance();
		HttpSession session = request.getSession();
		
		int study_id = Integer.parseInt(request.getParameter("study_id"));
		String member_id = MemberSessionUtils.getLoginmemberId(session);
		
		return null;
	}

}
