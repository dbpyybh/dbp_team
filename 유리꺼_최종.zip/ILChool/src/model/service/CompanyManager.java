package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Company;
import model.dao.CompanyDAO;
import model.dao.RecruitDAO;

public class CompanyManager {
	private static CompanyManager comMan = new CompanyManager();
	private CompanyDAO comDAO;

	private CompanyManager() {
		try {
			comDAO = new CompanyDAO();
		} catch (Exception e) {
			e.printStackTrace();
		}			
	}
	
	public static CompanyManager getInstance() {
		return comMan;
	}
	
	public List<Company> findCompanyList(String comName) {
		return comDAO.findCompanyListFromWorknet(comName);
	}
	
	public Company createCompany(Company com) throws SQLException {
		return comDAO.create(com);		
	}
}
