package model;

import java.util.Date;

public class Study {
	private int study_id;
	private String title;
	private String writer;
	private Date reportingDate;
	private String category;
	private String location;
	private String age;
	private String companyName;
	private int period;
	private int maxHeadcount;
	private int currHeadcount;
	
	public Study() { }
	
	
	public Study(int study_id, String title, String writer, Date reportingDate, String category, String location,
			String age, String companyName, int period, int maxHeadcount, int currHeadcount) {
		this.study_id = study_id;
		this.title = title;
		this.writer = writer;
		this.reportingDate = reportingDate;
		this.category = category;
		this.location = location;
		this.age = age;
		this.companyName = companyName;
		this.period = period;
		this.maxHeadcount = maxHeadcount;
		this.currHeadcount = currHeadcount;
	}


	public int getStudy_id() {
		return study_id;
	}


	public void setStudy_id(int study_id) {
		this.study_id = study_id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getWriter() {
		return writer;
	}


	public void setWriter(String writer) {
		this.writer = writer;
	}


	public Date getReportingDate() {
		return reportingDate;
	}


	public void setReportingDate(Date reportingDate) {
		this.reportingDate = reportingDate;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getAge() {
		return age;
	}


	public void setAge(String age) {
		this.age = age;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public int getPeriod() {
		return period;
	}


	public void setPeriod(int period) {
		this.period = period;
	}


	public int getMaxHeadcount() {
		return maxHeadcount;
	}


	public void setMaxHeadcount(int maxHeadcount) {
		this.maxHeadcount = maxHeadcount;
	}


	public int getCurrHeadcount() {
		return currHeadcount;
	}


	public void setCurrHeadcount(int currHeadcount) {
		this.currHeadcount = currHeadcount;
	}
	
	
	
}