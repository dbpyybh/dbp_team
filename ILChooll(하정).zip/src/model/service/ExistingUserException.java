package model.service;

/**
 * TODO
 */
public class ExistingUserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExistingUserException() {
		super();
	}

	public ExistingUserException(String arg0) {
		super(arg0);
	}
}
