package controller.main;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import controller.Controller;
import controller.member.MemberSessionUtils;
import model.TO_DO_LIST;
import model.service.TodoManager;


public class MainController implements Controller {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	/* 1. �޷� ������ �޾ƿ��� �κ� */
    	
    	
    	
    	
    	
    	/* 2. ���θ���Ʈ �޾ƿ��� �κ� */
    	HttpSession session = request.getSession();
        String memberid = MemberSessionUtils.getLoginmemberId(session);
        
        TodoManager manager = TodoManager.getInstance();
		List<TO_DO_LIST> todolist = manager.getTodoList(memberid);
		
        request.setAttribute("todolist", todolist);
        
        System.out.println(memberid + ", " + todolist.isEmpty());
    	
    	
    	/* 3. session(memberid) ���� �κ� */
        request.setAttribute("memberId", memberid);
        
        return "/main/MainUI.jsp";
    	
    }
}
