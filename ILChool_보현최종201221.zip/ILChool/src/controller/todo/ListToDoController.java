package controller.todo;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

import model.TO_DO_LIST;
import controller.Controller;
import model.service.TodoManager;

public class ListToDoController implements Controller {
	public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception{
		TodoManager manager = TodoManager.getInstance();
		List<TO_DO_LIST> todolist = manager.getTodoList();
		
		request.setAttribute("todolist", todolist);
		return "/Todo";
	}
}
