package controller.company;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Company;
import model.service.CompanyManager;

public class CreateCompanyController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(CreateCompanyController.class);

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	Company com = new Company(
        		0, request.getParameter("url"),
    			request.getParameter("name"),
    			request.getParameter("form"),
    			request.getParameter("summary"));
    	        
		try {
			CompanyManager comMan = CompanyManager.getInstance();
			comMan.createCompany(com);
			
	    	log.debug("Create Company : {}", com);
	        return "/DBPTeam/MainUI";	// ���� �� Ŀ�´�Ƽ ����Ʈ ȭ������ redirect
	        
		} catch (Exception e) {		// ���� �߻� �� �Է� form���� forwarding
            request.setAttribute("creationFailed", true);
			request.setAttribute("exception", e);
			request.setAttribute("com", com);
			return "/community/creationForm.jsp";
		}
    }

}
