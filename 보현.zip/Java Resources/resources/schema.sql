DROP SEQUENCE Sequence_269;

CREATE SEQUENCE Sequence_269
	INCREMENT BY 1
	START WITH 1;

DROP TABLE FamousSaying CASCADE CONSTRAINTS PURGE;

DROP TABLE TO_DO_LIST CASCADE CONSTRAINTS PURGE;

DROP TABLE Study_add_list CASCADE CONSTRAINTS PURGE;

DROP TABLE Study CASCADE CONSTRAINTS PURGE;

DROP TABLE Company_wish CASCADE CONSTRAINTS PURGE;

DROP TABLE Recruit_wish CASCADE CONSTRAINTS PURGE;

DROP TABLE Recruit CASCADE CONSTRAINTS PURGE;

DROP TABLE Company CASCADE CONSTRAINTS PURGE;

DROP TABLE Member CASCADE CONSTRAINTS PURGE;

CREATE TABLE Company
(
	company_id           INT NOT NULL ,
	name                 VARCHAR2(50) NULL ,
	form                 VARCHAR2(10) NULL ,
	summary              VARCHAR2(50) NULL ,
	location             VARCHAR2(10) NULL ,
	industry             VARCHAR2(10) NULL ,
	salary               INT NULL ,
	ceo                  VARCHAR2(40) NULL 
);

ALTER TABLE Company
	ADD CONSTRAINT  XPKCompany PRIMARY KEY (company_id);

CREATE TABLE Member
(
	member_id            INT NOT NULL ,
	name                 VARCHAR2(40) NULL ,
	phone                VARCHAR2(11) NULL ,
	email                VARCHAR2(40) NULL ,
	age                  VARCHAR2(10) NULL ,
	subDate              DATE NULL ,
	password             VARCHAR2(20) NULL 
);

ALTER TABLE Member
	ADD CONSTRAINT  XPKMember PRIMARY KEY (member_id);

CREATE TABLE TO_DO_LIST
(
	member_id            INT NOT NULL ,
	TO_DO                VARCHAR2(50) NULL ,
	TO_DO_id             INT NOT NULL 
);

ALTER TABLE TO_DO_LIST
	ADD CONSTRAINT  XPKTO_DO_LIST PRIMARY KEY (TO_DO_id,member_id);

CREATE TABLE Company_wish
(
	member_id            INT NOT NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Company_wish
	ADD CONSTRAINT  XPKCompany_wish PRIMARY KEY (member_id,company_id);

CREATE TABLE FamousSaying
(
	FamousSaying_id      INT NOT NULL ,
	FamousSaying         VARCHAR2(100) NULL 
);

ALTER TABLE FamousSaying
	ADD CONSTRAINT  XPKFamousSaying PRIMARY KEY (FamousSaying_id);

CREATE TABLE Recruit
(
	recruit_id           INT NOT NULL ,
	name                 VARCHAR2(40) NULL ,
	url                  VARCHAR2(2100) NULL ,
	form                 VARCHAR2(10) NULL ,
	career               VARCHAR2(10) NULL ,
	title                VARCHAR2(50) NULL ,
	location             VARCHAR2(10) NULL ,
	industry             VARCHAR2(10) NULL ,
	job                  VARCHAR2(18) NULL ,
	workingType          VARCHAR2(10) NULL ,
	regDate              DATE NULL ,
	deadline             DATE NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Recruit
	ADD CONSTRAINT  XPKRecruit PRIMARY KEY (recruit_id,company_id);

CREATE TABLE Recruit_wish
(
	member_id            INT NOT NULL ,
	recruit_id           INT NOT NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Recruit_wish
	ADD CONSTRAINT  XPKRecruit_wish PRIMARY KEY (member_id,recruit_id,company_id);

CREATE TABLE Study
(
	study_id             INT NOT NULL ,
	title                VARCHAR2(50) NULL ,
	writer				 VARCHAR2(20) NOT NULL ,
	reportingDate		 DATE NULL ,
	category             VARCHAR2(10) NULL ,
	location             VARCHAR2(10) NULL ,
	age                  VARCHAR2(10) NULL ,
	companyName          VARCHAR2(50) NULL ,
	period               INT NULL ,
	maxHeadcount		 INT NULL ,
	currHeadcount		 INT NULL,
);

ALTER TABLE Study
	ADD CONSTRAINT Study_pk PRIMARY KEY (study_id);
	
ALTER TABLE Study
	ADD (CONSTRAINT Study_writer_fk FOREIGN KEY (writer) REFERENCES Member (memberID));

CREATE TABLE Study_add_list
(
	member_id            INT NOT NULL ,
	Study_id             INT NOT NULL ,
	company_id           INT NOT NULL 
);

ALTER TABLE Study_add_list
	ADD CONSTRAINT  Study_add_list_pk PRIMARY KEY (member_id, study_id, company_id);

ALTER TABLE TO_DO_LIST
	ADD (CONSTRAINT R_8 FOREIGN KEY (member_id) REFERENCES Member (member_id));

ALTER TABLE Company_wish
	ADD (CONSTRAINT R_22 FOREIGN KEY (member_id) REFERENCES Member (member_id));

ALTER TABLE Company_wish
	ADD (CONSTRAINT R_23 FOREIGN KEY (company_id) REFERENCES Company (company_id));

ALTER TABLE Recruit
	ADD (CONSTRAINT R_25 FOREIGN KEY (company_id) REFERENCES Company (company_id));

ALTER TABLE Recruit_wish
	ADD (CONSTRAINT R_28 FOREIGN KEY (member_id) REFERENCES Member (member_id));

ALTER TABLE Recruit_wish
	ADD (CONSTRAINT R_29 FOREIGN KEY (recruit_id, company_id) REFERENCES Recruit (recruit_id, company_id));

ALTER TABLE Study
	ADD (CONSTRAINT R_24 FOREIGN KEY (company_id) REFERENCES Company (company_id));

ALTER TABLE Study_add_list
	ADD (CONSTRAINT R_10 FOREIGN KEY (member_id) REFERENCES Member (member_id));

ALTER TABLE Study_add_list
	ADD (CONSTRAINT R_11 FOREIGN KEY (study_id, company_id) REFERENCES Study (study_id, company_id));