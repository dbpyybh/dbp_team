package DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FSayingSQL {

	public FSayingSQL() {
		try {
			   Class.forName("oracle.jdbc.driver.OracleDriver"); 
			  } catch (ClassNotFoundException ex) {
			   ex.printStackTrace();
			  } 
	}
	
	private static Connection getConnection() {
		  String url = // "jdbc:oracle:thin:@localhost:1521:xe";
		     "jdbc:oracle:thin:@202.20.119.117:1521:orcl"; 
		  String user = "dbprog0210";
		  String passwd = "dbprog0210";
		
		  // DBMS�� ���� ȹ��
		  Connection conn = null;
		  try {
		   conn = DriverManager.getConnection(url, user, passwd);
		  } catch (SQLException e) {
		   e.printStackTrace();
		  } 
		  return conn;
	 }
	
	public static Connection Add() {
		 Connection conn = null;
		  PreparedStatement pStmt = null;   // PreparedStatment �������� ����
		  ResultSet rs = null;
		  int FAMOUSSAYING_ID = 0;
		  
		  String query = "SELECT FAMOUSSAYING" 
				  		+ "FROM FAMOUSSAYING"
				  		+ "WHERE FAMOUSSAYING_ID = 1";
		  
		  try {
			  conn = getConnection();
			  pStmt = conn.prepareStatement(query);
			  pStmt.setLong(1, FAMOUSSAYING_ID);
			  rs = pStmt.executeQuery();
			   
		  }catch(SQLException ex) {
			  ex.printStackTrace();
			} finally {// �ڿ� �ݳ�
			  if (pStmt != null)
			  try {
			   pStmt.close();
			  } catch (SQLException ex) { ex.printStackTrace(); }
			
			  if (conn != null)
			  try {
			  conn.close();
			  } catch (SQLException ex) {
			   ex.printStackTrace(); }
			}
		return conn;
	}
}
