package controller.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.service.MemberManager;

public class LoginController implements Controller {
private static final Logger log = LoggerFactory.getLogger(LoginController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
       String memberId = request.getParameter("memberId");
      String password = request.getParameter("password");
      
      try {
         // 筌뤴뫀�쑞占쎈퓠 嚥≪뮄�젃占쎌뵥 筌ｌ꼶�봺�몴占� 占쎌맄占쎌뿫
         MemberManager manager = MemberManager.getInstance();
         manager.login(memberId, password);
         
         HttpSession session = request.getSession();
            session.setAttribute(MemberSessionUtils.Member_SESSION_KEY, memberId);
            
            
         if (MemberSessionUtils.isLoginmember("admin", session))
            return "redirect:/member/list";   //�뵳�딅뮞占쎈뱜 占쎌넅筌롫똻�몵嚥≪뮄占썲칰占� �꽴占썹뵳�딆쁽 嚥≪뮄�젃占쎌뵥占쎌뵠筌롳옙.
         else
            return "/Main/main"; //占쎌뵬獄쏆꼷沅쀯옙�뒠占쎌쁽占쎌뵬野껋럩�뒭 占쎌돳占쎌뜚揶쏉옙占쎌뿯占쎈쨲占쎌몵嚥∽옙
             
      } catch (Exception e) {
         /* memberNotFoundException占쎌뵠占쎄돌 PasswordMismatchException 獄쏆뮇源� 占쎈뻻
          * 占쎈뼄占쎈뻻 login form占쎌뱽 占쎄텢占쎌뒠占쎌쁽占쎈퓠野껓옙 占쎌읈占쎈꽊占쎈릭�⑨옙 占쎌궎�몴占� 筌롫뗄苑�筌욑옙占쎈즲 �빊�뮆�젾
          
          */
            request.setAttribute("loginFailed", true);
         request.setAttribute("exception", e);
            return "/member/loginForm.jsp";         
      }   
    }
}