package controller;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.company.*;
import controller.main.*;
import controller.member.*;
import controller.recruit.*;
import controller.study.*;
import controller.todo.*;

public class RequestMapping {
    private static final Logger logger = LoggerFactory.getLogger(DispatcherServlet.class);
    
    // �� ��û uri�� ���� controller ��ü�� ������ HashMap ����
    private Map<String, Controller> mappings = new HashMap<String, Controller>();

    public void initMapping() {
    	// �� uri�� �����Ǵ� controller ��ü�� ���� �� ����
        mappings.put("/", new ForwardController("index.jsp"));
        mappings.put("/login", new ForwardController("login.jsp"));
//       mappings.put("/Login_v5/login", new LoginController());
//        mappings.put("/Login_v5/logout", new LogoutController());
        mappings.put("/Main/main", new MainController());
        mappings.put("/Main/MainUI", new ForwardController("/Main/MainUI.jsp"));

        mappings.put("/member/login/form", new ForwardController("/member/loginForm.jsp"));
        mappings.put("/member/login", new LoginController());
        mappings.put("/member/logout", new LogoutController());
        mappings.put("/member/list", new ListMemberController());
        mappings.put("/member/view", new ViewMemberController());
        mappings.put("/member/register/form", new ForwardController("/member/registerForm.jsp"));
        mappings.put("/member/register", new RegisterMemberController());
        mappings.put("/member/update/form", new UpdateMemberController());
        mappings.put("/member/update", new UpdateMemberController());
        mappings.put("/member/delete", new DeleteMemberController());
        //mappings.put("/DBPTeam/ToDo", new ListToDoController());
 
        
        mappings.put("/company/view", new ViewCompanyController());
        mappings.put("/company/create", new CreateCompanyController());
     //   mappings.put("/DBPTeam/ToDo", new ForwardController("/DBPTeam/MainUI.jsp"));
        
        mappings.put("/recruit/list", new ListRecruitController());
    	mappings.put("/recruit/view", new ViewRecruitController());
        mappings.put("/recruit/create", new CreateRecruitController());
        
        
        mappings.put("/study/list", new ListStudyController());
		mappings.put("/study/create/form", new ForwardController("/study/studyCreation.jsp"));
		mappings.put("/study/create", new CreateStudyController());
		mappings.put("/study/view", new ViewStudyController());
		mappings.put("/study/delete", new DeleteStudyController());
		mappings.put("/study/register", new RegisterStudyController());
		
		
        mappings.put("/Todo", new ForwardController("/todo/ToDo.jsp"));
        mappings.put("/todo/list", new ListToDoController());
        mappings.put("/todo/create", new CreateToDoController());
       // mappings.put("", remappingFunction)
//        mappings.put("/DBPTeam/ToDo", new TodoController());
        //        mappings.put("/user/view", new ViewUserController());
//        mappings.put("/user/register/form", new ForwardController("/user/registerForm.jsp"));
//        mappings.put("/user/register", new RegisterUserController());
        
        mappings.put("/view", new ViewCompanyController());
        mappings.put("/create", new CreateCompanyController());
//
//        // ����� ���� ���� �� ��û�� ���� ��û ó�� ����
////      mappings.put("/user/update/form", new UpdateUserFormController());
//        mappings.put("/user/update/form", new UpdateUserController());
//        mappings.put("/user/update", new UpdateUserController());
//        mappings.put("/user/delete", new DeleteUserController());
//        
//        // Ŀ�´�Ƽ ���� request URI �߰�
//        mappings.put("/community/list", new ListCommunityController());
//        mappings.put("/community/view", new ViewCommunityController());
//        mappings.put("/community/create/form", new ForwardController("/community/creationForm.jsp"));
//        mappings.put("/community/create", new CreateCommunityController());
//        mappings.put("/community/update/form", new UpdateCommunityController());
//        mappings.put("/community/update", new UpdateCommunityController());
        
        logger.info("Initialized Request Mapping!");
    }

    public Controller findController(String uri) {	
    	// �־��� uri�� �����Ǵ� controller ��ü�� ã�� ��ȯ
        return mappings.get(uri);
    }
}