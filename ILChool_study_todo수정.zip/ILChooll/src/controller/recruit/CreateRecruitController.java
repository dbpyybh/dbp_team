package controller.recruit;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Recruit;
import model.service.RecruitManager;

public class CreateRecruitController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(CreateRecruitController.class);

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	SimpleDateFormat df = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);

    	Recruit rec = new Recruit(
        		0, request.getParameter("name"),
    			request.getParameter("url"),
    			request.getParameter("form"),
    			request.getParameter("title"),
    			request.getParameter("workingType"),
    			df.parse(request.getParameter("regDate")),
    			df.parse(request.getParameter("deadline")),
    			0);
   	        
		try {
			RecruitManager recMan = RecruitManager.getInstance();
			recMan.createRecruit(rec);
			
	    	log.debug("Create Recruit : {}", rec);
	        return "/recruit/list";	// ���� �� Ŀ�´�Ƽ ����Ʈ ȭ������ redirect
	        
		} catch (Exception e) {		// ���� �߻� �� �Է� form���� forwarding
            request.setAttribute("creationFailed", true);
			request.setAttribute("exception", e);
			request.setAttribute("com", rec);
			return "/community/creationForm.jsp";
		}
    }

}
